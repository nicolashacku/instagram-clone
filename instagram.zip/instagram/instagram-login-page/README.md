# Instagram Clone

Olá, recriei a página de login do instagram com a finalidade de práticar alguns conhecimentos.

-   Flexbox
    -   Flex-direction, justify-content e align-items, flex-wrap.
-   Media queries
    -   Todo o site é responsivo para smartphones, tablets e desktops.
 - Pré-processador CSS
    -   Foi utilizado Sass para criar um código limpo e com fácil manutenção, utilizando 	nesting, variáveis, imports e mixins.

